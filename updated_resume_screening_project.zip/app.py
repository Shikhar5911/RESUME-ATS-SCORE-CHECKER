
import streamlit as st
import os
import pandas as pd

from utils.pdf_extractor import extract_resume_text
from models.embedding_model import load_model
from utils.similarity import calculate_similarity
from utils.skill_extractor import extract_skills
from utils.skill_matcher import skill_match

st.title("AI Resume Screening System (Updated)")

uploaded_files = st.file_uploader(
    "Upload Multiple Resumes (PDF)", 
    type="pdf", 
    accept_multiple_files=True
)

job_description = st.text_area("Enter Job Description")

if uploaded_files and job_description:
    model = load_model()

    results = []

    for file in uploaded_files:
        text = extract_resume_text(file)

        similarity_score = calculate_similarity(text, job_description, model)
        skills_resume = extract_skills(text)
        skills_job = extract_skills(job_description)
        skill_score = skill_match(skills_resume, skills_job)

        final_score = (similarity_score * 0.7) + (skill_score * 0.3)

        results.append({
            "Resume": file.name,
            "Similarity Score": round(similarity_score, 2),
            "Skill Match": round(skill_score, 2),
            "Final Score": round(final_score, 2)
        })

    df = pd.DataFrame(results)
    df = df.sort_values(by="Final Score", ascending=False)

    st.subheader("All Resume Scores")
    st.dataframe(df)

    best_candidate = df.iloc[0]

    st.subheader("Best Candidate Selected")
    st.success(f"Selected Resume: {best_candidate['Resume']} with score {best_candidate['Final Score']}")
