# AI Resume Screening System

This project ranks resumes automatically based on similarity to a job description using NLP and BERT embeddings.

## Features
- Upload multiple resumes (PDF)
- Extract text from resumes
- Generate embeddings using Sentence Transformers
- Calculate cosine similarity
- Rank candidates automatically
- Skill extraction and skill match percentage
- Streamlit dashboard

## Tech Stack
Python, Streamlit, NLP, Sentence Transformers, Scikit-learn

## Run the Project

Install dependencies:

pip install -r requirements.txt

Run the application:

streamlit run app.py