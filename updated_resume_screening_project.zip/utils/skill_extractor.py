import re

skills_db = [
    "python","machine learning","deep learning",
    "sql","tableau","power bi","pandas",
    "numpy","tensorflow","pytorch","nlp"
]

def extract_skills(text):

    text = text.lower()
    found_skills = []

    for skill in skills_db:
        if re.search(skill, text):
            found_skills.append(skill)

    return list(set(found_skills))