from sklearn.metrics.pairwise import cosine_similarity

def calculate_similarity(model, resume_text, job_description):

    embeddings = model.encode([resume_text, job_description])

    resume_embedding = embeddings[0].reshape(1,-1)
    jd_embedding = embeddings[1].reshape(1,-1)

    score = cosine_similarity(resume_embedding, jd_embedding)

    return score[0][0]